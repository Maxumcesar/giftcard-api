# Giftcard API

Una API simple para vender tarjetas de regalo virtuales con pagos simulados.